package com.example.demo.service;
import com.example.demo.dto.InsurenceRequestDto;

public interface InsurenceService {
	
	
	public String insurenceTicket(InsurenceRequestDto insurencerequest);

}
